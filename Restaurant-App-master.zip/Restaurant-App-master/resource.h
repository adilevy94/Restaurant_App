//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by RestaurantProj.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_RESTAURANT_PROJ_DIALOG      102
#define IDR_MAINFRAME                   128
#define IDR_MENU1                       136
#define IDR_TOOLBAR1                    137
#define IDC_CHECK1                      1006
#define IDC_CHECK2                      1007
#define IDC_CHECK3                      1008
#define IDC_CHECK5                      1011
#define IDC_CHECK6                      1012
#define IDC_BUTTON1                     1013
#define IDC_CHECK7                      1014
#define IDC_BUTTON2                     1015
#define IDC_BUTTON3                     1016
#define IDC_RADIO1                      1017
#define IDC_RADIO2                      1018
#define IDC_RADIO3                      1019
#define IDC_DATETIMEPICKER1             1036
#define IDC_RADIO4                      1037
#define IDC_RADIO5                      1038
#define IDC_RADIO6                      1039
#define IDC_RADIO7                      1040
#define IDC_RADIO8                      1041
#define IDC_RADIO10                     1043
#define IDC_RADIO11                     1044
#define IDC_BUTTON4                     1045
#define IDC_CHECK4                      1048
#define IDC_CHECK8                      1049
#define IDC_CHECK9                      1050
#define IDC_LIST2                       1075
#define IDC_BUTTON5                     1077
#define IDC_BUTTON7                     1080
#define IDC_BUTTON8                     1081
#define IDC_BUTTON6                     1082
#define IDC_BUTTON9                     1083
#define IDC_BUTTON10                    1084
#define ID_FILE_NEW32771                32771
#define ID_FILE_OPEN32772               32772
#define ID_FILE_SAVE32773               32773

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        139
#define _APS_NEXT_COMMAND_VALUE         32774
#define _APS_NEXT_CONTROL_VALUE         1085
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
